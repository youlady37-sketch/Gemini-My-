(() => {
  // src/utils/formatter.ts
  function normalizeQuotesAndCurrency(text) {
    if (!text) return "";
    return text.replace(/[«»“”„‟]/g, '"').replace(/₽/g, " \u0440\u0443\u0431.").replace(/ {2,}/g, " ");
  }
  function stripHtml(html) {
    if (!html) return "";
    const tmp = document.createElement("div");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
  }

  // src/content/extractor.ts
  function extractVacancyFromDocument(doc = document, currentUrl = window.location.href) {
    const vacancyIdMatch = currentUrl.match(/\/vacancy\/(\d+)/);
    let vacancyId = vacancyIdMatch ? vacancyIdMatch[1] : null;
    const jsonLdData = extractFromJsonLd(doc);
    let title = querySelectorText(doc, [
      '[data-qa="vacancy-title"]',
      'h1[data-qa="vacancy-title"]',
      "h1.bloko-header-section-1",
      'h1[itemprop="title"]',
      ".vacancy-title",
      "h1"
    ]);
    if (!title && jsonLdData?.title) {
      title = jsonLdData.title;
    }
    if (!title) {
      const pageTitle = doc.title;
      if (pageTitle && pageTitle.toLowerCase().includes("\u0432\u0430\u043A\u0430\u043D\u0441\u0438\u044F")) {
        title = pageTitle.split("\u2014")[0]?.split("|")[0]?.trim() || pageTitle;
      }
    }
    if (!title) {
      return null;
    }
    let company = querySelectorText(doc, [
      '[data-qa="vacancy-company-name"]',
      '[data-qa="vacancy-company-name-inline"]',
      '[data-qa="vacancy-company"]',
      'a[itemprop="hiringOrganization"]',
      ".vacancy-company-name",
      '[data-qa="employer-title"]',
      ".vacancy-company-name-wrapper"
    ]);
    if (!company && jsonLdData?.company) {
      company = jsonLdData.company;
    }
    let salary = querySelectorText(doc, [
      '[data-qa="vacancy-salary"]',
      '[data-qa="vacancy-salary-compensation-type-net"]',
      '[data-qa="vacancy-salary-compensation-type-gross"]',
      ".vacancy-salary",
      'span[data-qa="vacancy-salary-compensation-type-net"]',
      '[itemprop="baseSalary"]'
    ]);
    if (!salary && jsonLdData?.salary) {
      salary = jsonLdData.salary;
    }
    let location = querySelectorText(doc, [
      '[data-qa="vacancy-view-raw-address"]',
      '[data-qa="vacancy-view-location"]',
      'span[itemprop="addressLocality"]',
      '[data-qa="vacancy-address"]',
      ".vacancy-address-text"
    ]);
    if (!location && jsonLdData?.location) {
      location = jsonLdData.location;
    }
    const employmentType = querySelectorText(doc, [
      '[data-qa="vacancy-view-employment-mode"]',
      'p[data-qa="vacancy-view-employment-mode"]',
      'span[itemprop="employmentType"]'
    ]);
    const schedule = querySelectorText(doc, [
      '[data-qa="vacancy-view-work-schedule"]',
      'span[itemprop="workHours"]'
    ]);
    let description = "";
    const descElem = querySelectorFirst(doc, [
      '[data-qa="vacancy-description"]',
      ".g-user-content",
      '[itemprop="description"]',
      ".vacancy-description"
    ]);
    if (descElem) {
      description = stripHtml(descElem.innerHTML).trim();
    } else if (jsonLdData?.description) {
      description = stripHtml(jsonLdData.description).trim();
    }
    const skillElements = doc.querySelectorAll(
      '[data-qa="bloko-tag__text"], [data-qa="skills-element"], .bloko-tag__text, .bloko-tag_inline'
    );
    const skills = [];
    skillElements.forEach((el) => {
      const text = el.textContent?.trim();
      if (text && !skills.includes(text)) {
        skills.push(text);
      }
    });
    const { requirements, responsibilities } = extractListSections(doc, descElem);
    title = normalizeQuotesAndCurrency(title);
    if (company) company = normalizeQuotesAndCurrency(company);
    if (salary) salary = normalizeQuotesAndCurrency(salary);
    return {
      vacancyId,
      url: currentUrl,
      title,
      company: company || null,
      description: description || title,
      requirements,
      responsibilities,
      skills,
      salary: salary || null,
      employmentType: employmentType || null,
      schedule: schedule || null,
      location: location || null,
      extractedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  function querySelectorText(root, selectors) {
    for (const sel of selectors) {
      try {
        const el = root.querySelector(sel);
        if (el && el.textContent) {
          const cleaned = el.textContent.trim();
          if (cleaned) return cleaned;
        }
      } catch {
      }
    }
    return null;
  }
  function querySelectorFirst(root, selectors) {
    for (const sel of selectors) {
      try {
        const el = root.querySelector(sel);
        if (el) return el;
      } catch {
      }
    }
    return null;
  }
  function extractFromJsonLd(doc) {
    try {
      const scripts = doc.querySelectorAll('script[type="application/ld+json"]');
      for (let i = 0; i < scripts.length; i++) {
        const text = scripts[i].textContent;
        if (!text) continue;
        const parsed = JSON.parse(text);
        const item = Array.isArray(parsed) ? parsed.find((x) => x["@type"] === "JobPosting") : parsed;
        if (item && (item["@type"] === "JobPosting" || item["title"])) {
          let salaryStr;
          if (item.baseSalary) {
            const val = item.baseSalary.value;
            const currency = item.baseSalary.currency === "RUR" || item.baseSalary.currency === "RUB" ? "\u0440\u0443\u0431." : item.baseSalary.currency;
            if (val) {
              if (typeof val === "object") {
                const min = val.minValue || val.value;
                const max = val.maxValue;
                salaryStr = max ? `\u043E\u0442 ${min} \u0434\u043E ${max} ${currency}` : `${min} ${currency}`;
              } else {
                salaryStr = `${val} ${currency}`;
              }
            }
          }
          return {
            title: item.title,
            company: item.hiringOrganization?.name,
            salary: salaryStr,
            location: item.jobLocation?.address?.addressLocality || item.jobLocation?.address?.streetAddress,
            description: item.description
          };
        }
      }
    } catch (e) {
    }
    return null;
  }
  function extractListSections(doc, descContainer) {
    const requirements = [];
    const responsibilities = [];
    const root = descContainer || doc.body;
    if (!root) return { requirements, responsibilities };
    const paragraphs = root.querySelectorAll("p, strong, b, div.bloko-header-section-2, div.bloko-header-section-3, h2, h3, h4");
    paragraphs.forEach((header) => {
      const text = header.textContent?.toLowerCase().trim() || "";
      const isReq = text.includes("\u0442\u0440\u0435\u0431\u043E\u0432\u0430\u043D") || text.includes("\u043E\u0436\u0438\u0434\u0430\u043D") || text.includes("\u0436\u0434\u0435\u043C") || text.includes("\u043D\u0435\u043E\u0431\u0445\u043E\u0434\u0438\u043C") || text.includes("\u043D\u0430\u0448 \u043A\u0430\u043D\u0434\u0438\u0434\u0430\u0442");
      const isResp = text.includes("\u043E\u0431\u044F\u0437\u0430\u043D\u043D\u043E\u0441\u0442") || text.includes("\u0437\u0430\u0434\u0430\u0447") || text.includes("\u043F\u0440\u0435\u0434\u0441\u0442\u043E\u0438\u0442") || text.includes("\u0447\u0435\u043C \u0437\u0430\u043D\u0438\u043C\u0430\u0442");
      if (isReq || isResp) {
        let next = header.nextElementSibling;
        let depth = 0;
        while (next && depth < 4) {
          if (next.tagName === "UL" || next.tagName === "OL") {
            const items = next.querySelectorAll("li");
            items.forEach((li) => {
              const liText = li.textContent?.trim();
              if (liText && liText.length > 5) {
                if (isReq && !requirements.includes(liText)) requirements.push(liText);
                if (isResp && !responsibilities.includes(liText)) responsibilities.push(liText);
              }
            });
            break;
          }
          next = next.nextElementSibling;
          depth++;
        }
      }
    });
    return { requirements, responsibilities };
  }

  // src/content/index.ts
  var currentVacancyCache = null;
  var lastUrl = window.location.href;
  var badgeElement = null;
  function isVacancyUrl(url) {
    return url.includes("hh.ru/vacancy/") || url.includes("/vacancy/");
  }
  function processCurrentPage() {
    const currentUrl = window.location.href;
    if (!isVacancyUrl(currentUrl)) {
      removeBadge();
      currentVacancyCache = null;
      return;
    }
    const vacancy = extractVacancyFromDocument(document, currentUrl);
    if (vacancy && vacancy.title) {
      currentVacancyCache = vacancy;
      if (typeof chrome !== "undefined" && chrome.storage?.local) {
        chrome.storage.local.set({ hh_reply_ai_current_vacancy: vacancy });
      }
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        try {
          chrome.runtime.sendMessage({
            type: "VACANCY_DETECTED",
            payload: vacancy
          });
        } catch (err) {
        }
      }
      injectOrUpdateBadge(vacancy);
    }
  }
  function injectOrUpdateBadge(vacancy) {
    if (document.getElementById("hh-reply-ai-badge")) {
      return;
    }
    badgeElement = document.createElement("div");
    badgeElement.id = "hh-reply-ai-badge";
    badgeElement.setAttribute(
      "style",
      'position: fixed; bottom: 24px; right: 24px; z-index: 999999; background: #0f172a; color: #ffffff; border: 1px solid rgba(255,255,255,0.15); padding: 10px 16px; border-radius: 9999px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; font-size: 13px; font-weight: 500; cursor: pointer; display: flex; align-items: center; gap: 8px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3); transition: transform 0.2s ease, background 0.2s ease;'
    );
    badgeElement.innerHTML = `
    <span style="font-size: 15px;">\u2728</span>
    <span>HH Reply AI: <strong>${vacancy.company ? vacancy.company.substring(0, 18) : "\u0412\u0430\u043A\u0430\u043D\u0441\u0438\u044F"}</strong></span>
    <span style="background: #2563eb; color: #fff; font-size: 11px; padding: 2px 7px; border-radius: 12px; margin-left: 4px;">Side Panel</span>
  `;
    badgeElement.addEventListener("mouseenter", () => {
      badgeElement.style.transform = "translateY(-2px)";
    });
    badgeElement.addEventListener("mouseleave", () => {
      badgeElement.style.transform = "translateY(0)";
    });
    badgeElement.addEventListener("click", () => {
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        chrome.runtime.sendMessage({ type: "OPEN_SIDE_PANEL" });
      }
    });
    document.body.appendChild(badgeElement);
  }
  function removeBadge() {
    const el = document.getElementById("hh-reply-ai-badge");
    if (el && el.parentNode) {
      el.parentNode.removeChild(el);
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime?.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message.type === "REQUEST_VACANCY_EXTRACT") {
        const vacancy = extractVacancyFromDocument(document, window.location.href);
        if (vacancy) {
          currentVacancyCache = vacancy;
          sendResponse(vacancy);
        } else {
          sendResponse(currentVacancyCache);
        }
        return true;
      }
    });
  }
  function observeNavigation() {
    const observer = new MutationObserver(() => {
      if (window.location.href !== lastUrl) {
        lastUrl = window.location.href;
        processCurrentPage();
      }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    window.addEventListener("popstate", () => {
      processCurrentPage();
    });
    const originalPushState = history.pushState;
    history.pushState = function(...args) {
      originalPushState.apply(this, args);
      setTimeout(processCurrentPage, 300);
    };
    const originalReplaceState = history.replaceState;
    history.replaceState = function(...args) {
      originalReplaceState.apply(this, args);
      setTimeout(processCurrentPage, 300);
    };
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      setTimeout(processCurrentPage, 500);
      observeNavigation();
    });
  } else {
    setTimeout(processCurrentPage, 300);
    observeNavigation();
  }
})();
